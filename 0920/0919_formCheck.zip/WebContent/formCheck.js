//	자바스크립트 함수의 형식
//	function 함수이름([인수, ...]) {
//		함수가 실행할 문장;
//		...;
//		[return 값;]
//	}
	
//	이벤트가 실행되는 객체(주민등록번호 앞, 뒤 자리)에 최대 글자수 만큼 문자가 입력되면 지정한 객체로 포커스를 넘겨주는 함수
//	moveNext(이벤트가 실행되는 객체, 최대 글자수, 포커스를 넘겨줄 객체)
function moveNext(obj, len, nentObj) {
	
//	value : 객체에 입력된 문자열, length : 객체에 입력된 문자열의 개수
	if (obj.value.length == len) {
		nentObj.focus();
	}
	
}

//	폼에 입력된 주민등록번호가 올바른 데이터인가 검사하는 함수
//	obj로 this가 넘어오므로 obj에는 document.juminForm이 저장된다.
function formCheck(obj) {
	
//	주민등록번호 앞 자리에 데이터가 입력되었나 확인한다. => 아무것도 입력하지 않았거나 모두 공백이 입력된 경우
//	obj.j1.value => 주민등록번호 앞자리(j1)에 입력된 데이터(value)가 있으면 true, 없으면 false
	if (!obj.j1.value || obj.j1.value.trim().length == 0) {
		alert('주민등록번호 앞 자리를 입력하세요');
		obj.j1.value = '';
		obj.j1.focus();
		return false;
	}
	
//	주민등록번호 앞 자리에 6글자가 입력되었나 확인한다.
	if (obj.j1.value.trim().length != 6) {
		alert('주민등록번호 앞 자리는 6글자를 입력하세요');
		obj.j1.value = '';
		obj.j1.focus();
		return false;
	}
	
//	주민등록번호 앞 자리에 숫자만 입력되었나 검사한다.
//	Number() : 인수로 지정된 문자열을 숫자로 변환한다.
//	isNaN() : NaN => Not a Number, 인수로 지정된 데이터가 숫자가 아니면 true, 숫자면 false를 리턴한다.
	if (isNaN(Number(obj.j1.value))) {
		alert('주민등록번호 앞 자리는 숫자만 입력하세요');
		obj.j1.value = '';
		obj.j1.focus();
		return false;
	}
	
	
	if (!obj.j2.value || obj.j2.value.trim().length == 0) {
		alert('주민등록번호 뒷 자리를 입력하세요');
		obj.j2.value = '';
		obj.j2.focus();
		return false;
	}
	if (obj.j2.value.trim().length != 7) {
		alert('주민등록번호 뒷 자리는 7글자를 입력하세요');
		obj.j2.value = '';
		obj.j2.focus();
		return false;
	}
	if (isNaN(Number(obj.j2.value))) {
		alert('주민등록번호 뒷 자리는 숫자만 입력하세요');
		obj.j2.value = '';
		obj.j2.focus();
		return false;
	}

//	여기까지 왔다는 것은 주민등록번호는 13자리의 숫자가 입력되었다는 의미이다. => 주민등록번호 유효성 검사
//	주민등록번호 유효성 검사를 하기 위해서 주민등록번호를 하나의 문자열로 합친다.
//	자바스크립트는 숫자로만 구성된 문자열을 사칙연산을 할 경우 덧셈을 하는 경우에는 문자열을 이어 붙이고 덧셈을 제외한 나머지 연산은
//	지가 알아서 숫자로 변환시킨 후 연산한다.
	var jumin = obj.j1.value + obj.j2.value;
//	숫자로만 구성된 문자열을 덧셈 연산을 하려면 Number() 함수를 사용해서 숫자로 변환시킨 후 해야한다.
//	var jumin = Number(obj.j1.value) + Number(obj.j2.value);
	console.log(jumin);
//	alert(jumin);

	var sum = 0;
//	주민등록번호의 각 자리 숫자와 가중치를 곱한 합계를 계산한다.
	for (var i = 0; i < 12; i++) {
		sum += jumin.charAt(i) * (i % 8 + 2);
	}
	console.log(sum);
	
//	합계를 11로 나눈 나머지를 11에서 뺀 결과가 2자리 숫자일 경우 10의 자리는 버리고 1의 자리만 취한다.
	var result = (11 - sum % 11) % 10;
	console.log(result);
	
//	계산에 의해 얻어진 1의 자리와 주민등록번호 마지막 자리를 비교해서 같으면 정상적인 주민등록번호이다.
//	==와 !=는 데이터 타입은 비교하지 않고 값만 비교하므로 1와 '1'를 비교하면 같다고 판정한다.
//	===와 !==는 데이터 타입을 먼저 비교하고 데이터 타입이 같을 경우 데이터를 비교한다. 1와 '1'를 비교하면 다르다고 판정한다.
	if (jumin.charAt(12) != result) {
		alert('올바른 주민등록번호가 아닙니다. 넌.... 누구냐???');
		obj.j1.value = '';
		obj.j2.value = '';
		obj.j1.focus();
		return false;
	}
	
//	오류 없이 여기까지 실행되었다면 정상적인 데이터가 입력된 것이므로 true를 리턴시킨다.
	return true;
	
}




	
	






