package com.koreait.onlinepoll;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class PollWrite {

//	텍스트 파일을 저장할 경로와 파일 이름, 텍스트 파일에 저장할 데이터가 저장된 ArrayList를 넘겨받아 텍스트 파일로 저장하는 메소드
	public static void pollWrite(String filename, ArrayList<String> poll) {
		
//		ArrayList에 저장된 데이터를 텍스트 파일로 출력할 때 사용할 PrintWriter 객체를 선언한다.
		PrintWriter printWriter = null;
		
		try {
//			ArrayList에 저장된 데이터를 텍스트 파일로 출력하는 객체를 생성한다.
			printWriter = new PrintWriter(filename);
			
//			텍스트 파일로 출력할 객체가 생성되었으므로 ArrayList에 저장된 데이터의 개수 만큼 반복하며 텍스트 파일로 출력한다.
//			for (int i = 0; i < poll.size(); i++) {
//				printWriter.write(poll.get(i) + "\r\n");
//			}
			
			for (String str : poll) {
				printWriter.write(str + "\r\n");
			}
			
		} catch (FileNotFoundException e) {
			System.out.println("디스크에 파일이 존재하지 않습니다.");
			e.printStackTrace();
		} finally {
			if (printWriter != null) {
				printWriter.close();
			}
		}
		
		
	}
	
}











